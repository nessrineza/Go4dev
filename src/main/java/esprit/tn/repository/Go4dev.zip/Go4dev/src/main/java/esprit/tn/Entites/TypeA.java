package esprit.tn.Entites;

public enum TypeA {
    APARTMENT,DUPLEX,TRIPLEX,OFFICE,OTHER
}
