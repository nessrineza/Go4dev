package esprit.tn.Entites;

public enum Subject {
    PRICE,DELY,OTHER
}
