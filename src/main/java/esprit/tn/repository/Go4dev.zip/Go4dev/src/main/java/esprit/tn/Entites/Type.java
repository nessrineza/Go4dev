package esprit.tn.Entites;

public enum Type {
    CASH,ONLINE;
}
