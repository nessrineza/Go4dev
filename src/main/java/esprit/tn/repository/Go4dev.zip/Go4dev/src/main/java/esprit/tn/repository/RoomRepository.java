package esprit.tn.repository;

import esprit.tn.Entites.Room;
import org.springframework.data.repository.CrudRepository;

public interface RoomRepository extends CrudRepository<Room,Integer> {
}
