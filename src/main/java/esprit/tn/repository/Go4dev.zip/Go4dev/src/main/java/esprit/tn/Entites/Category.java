package esprit.tn.Entites;

public enum Category {
    RENT,SALE
}
