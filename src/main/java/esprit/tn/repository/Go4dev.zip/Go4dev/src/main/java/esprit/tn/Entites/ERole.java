package esprit.tn.Entites;

public enum ERole {
  ROLE_CLIENT,
  ROLE_ADMIN
}
